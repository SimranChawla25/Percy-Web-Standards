package com.yourcompany;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class HelloWorldTest {

    public static void main(String[] args) {
        // Set the path to ChromeDriver
        System.setProperty("webdriver.chrome.driver", "path/to/your/chromedriver");

        // Create a new instance of ChromeDriver
        WebDriver driver = new ChromeDriver();

        // Open a website (example: Google)
        driver.get("https://www.google.com");

        // Print the page title to confirm Selenium is working
        System.out.println("Page Title: " + driver.getTitle());

        // Close the browser
        driver.quit();
    }
}