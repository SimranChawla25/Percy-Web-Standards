package com.yourcompany;

import java.io.*;
import java.nio.file.*;
import java.time.Duration;
import java.util.*;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.*;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.support.ui.*;
import org.apache.commons.io.FileUtils;
import java.awt.*;
import java.awt.image.*;
import javax.imageio.ImageIO;

public class App {

    public static void main(String[] args) {
        // Setup WebDriver for Chrome
        System.setProperty("webdriver.chrome.driver", "/Users/simranchawla/Downloads/chromedriver-mac-arm64/chromedriver");  // Specify your chromedriver path here
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--disable-web-security");
        options.addArguments("--disable-site-isolation-trials");

        // Initialize WebDriver
        WebDriver driver = new ChromeDriver(options);

        // List to store the screenshot filenames
        List<String> imageList = new ArrayList<>();

        try {
            // Open the page and set window size
            driver.get("https://store.standards.org.au/reader/as-3633-1989?preview=1");
            System.out.println("Navigated to URL: " + driver.getCurrentUrl());  // Log the current URL

            driver.manage().window().setSize(new Dimension(1280, 800));

            // Wait for the body of the page to load
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.tagName("body")));  // Wait for the body of the page to be visible

            // Wait for the 'ereader-content' to be visible before scrolling
            WebElement contentElement = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ereader-content")));

            // Scroll the 'ereader-content' element
            ((JavascriptExecutor) driver).executeScript("document.getElementById('ereader-content').scrollBy(0, 0);");
            TimeUnit.SECONDS.sleep(2);  // Allow page to load

            long currentHeight = (long) ((JavascriptExecutor) driver).executeScript("return arguments[0].clientHeight;", contentElement);
            long scrollPosition = 0;

            // Create directories if they do not exist
            createDirectory("imgs");
            createDirectory("main_tiles");

            // Flag to check if it's the first screenshot (first page)
            boolean isFirstPage = true;

            // Take screenshots by scrolling
            for (int tile = 0; tile < 1; tile++) {  // 1 main tile for simplicity in this example
                for (int i = 0; i < 10; i++) {  // 10 screenshots per main tile
                    
                    // Scroll the 'ereader-content' element
                 // Allow page to load

                    // Capture screenshot
                    String screenshotName = "imgs/Sub_Tile_" + (i + 1) + ".png";
                    File screenshot=contentElement.getScreenshotAs(OutputType.FILE);
                    BufferedImage img = ImageIO.read(screenshot);

                   
                    BufferedImage finalImage;
               
                    File destinationFile = new File(screenshotName);
                    ImageIO.write(img, "PNG", destinationFile);
                    ((JavascriptExecutor) driver).executeScript("document.getElementById('ereader-content').scrollBy(0, arguments[0]);",currentHeight);
                    TimeUnit.SECONDS.sleep(2); 
                    imageList.add(screenshotName);  // Add to image list
                    scrollPosition += currentHeight;  // Scroll further down
                }

                // After capturing all sub-tiles, stitch images vertically for this tile
                String mainTileName = "main_tiles/Tile_" + (tile + 1) + ".png";
                stitchImagesVertically(imageList, mainTileName);
                imageList.clear();  // Clear list for the next tile
            }

            // Upload the images using Percy (run in terminal with appropriate token)
            String percyToken = "<your percy token>";  // Replace with your Percy token
            uploadToPercy(percyToken);

            // Clean up by deleting the directories
             deleteDirectory(Paths.get("imgs"));
            deleteDirectory(Paths.get("main_tiles"));
            System.out.println("Directories cleaned up.");

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            driver.quit();  // Ensure driver quits after completion
        }
    }

    // Function to create a directory if it does not exist
    public static void createDirectory(String dirName) {
        File directory = new File(dirName);
        if (!directory.exists()) {
            directory.mkdirs();
            System.out.println("Created directory: " + dirName);
        }
    }

    // Function to stitch images vertically
    public static void stitchImagesVertically(List<String> imagePaths, String outputPath) throws IOException {
        BufferedImage[] images = new BufferedImage[imagePaths.size()];
        for (int i = 0; i < imagePaths.size(); i++) {
            images[i] = ImageIO.read(new File(imagePaths.get(i)));
        }

        // Calculate the total width and height of the stitched image
        int totalWidth = 0;
        int totalHeight = 0;
        for (BufferedImage img : images) {
            totalWidth = Math.max(totalWidth, img.getWidth()); // Use the widest image
            totalHeight += img.getHeight(); // Sum all heights
        }

        // Create a new image to hold the stitched result
        BufferedImage stitchedImage = new BufferedImage(totalWidth, totalHeight, BufferedImage.TYPE_INT_RGB);

        // Draw each image onto the new image
        Graphics2D g2d = stitchedImage.createGraphics();
        int currentY = 0;
        for (BufferedImage img : images) {
            g2d.drawImage(img, 0, currentY, null);
            currentY += img.getHeight();  // Move down by the height of the pasted image
            System.out.println(currentY +":"+ img.getHeight());
        }
        g2d.dispose();  // Release resources

        // Save the final stitched image
        ImageIO.write(stitchedImage, "PNG", new File(outputPath));
        System.out.println("Stitched image saved at " + outputPath);
    }

    // Function to upload images to Percy 
    public static void uploadToPercy(String percyToken) {
        try {
            // Prepare the command to upload the images using Percy CLI
            String command = "PERCY_TOKEN=" + percyToken + " npx percy upload ./main_tiles";

            // Create a process builder to run the command
            ProcessBuilder processBuilder = new ProcessBuilder("bash", "-c", command);
            processBuilder.inheritIO();  // This will allow the output to be displayed in the console
            Process process = processBuilder.start();

            // Wait for the process to finish
            int exitCode = process.waitFor();
            if (exitCode == 0) {
                System.out.println("Percy upload completed successfully.");
            } else {
                System.err.println("Error during Percy upload. Exit code: " + exitCode);
            }
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }

    // Function to delete a directory and its contents
    public static void deleteDirectory(Path path) throws IOException {
        if (Files.exists(path)) {
            Files.walk(path)
                .sorted(Comparator.reverseOrder())  // Start from the deepest file/folder
                .map(Path::toFile)
                .forEach(File::delete);
            System.out.println("Deleted directory: " + path);
        }
    }
}
